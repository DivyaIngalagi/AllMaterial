function ExplicitReturn(message) {
  return message;
}
