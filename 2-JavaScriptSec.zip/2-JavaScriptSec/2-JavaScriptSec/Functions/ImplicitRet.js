function ImplicitReturn(message) {
  // without return keyword, it return value always
}
