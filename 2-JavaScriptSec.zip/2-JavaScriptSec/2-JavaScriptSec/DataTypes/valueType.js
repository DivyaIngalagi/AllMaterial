var name1 = "paresh"; // global

alert(window.name1);

name1 = 456;

alert("after change:" + name1);

const PRICE = 56;
