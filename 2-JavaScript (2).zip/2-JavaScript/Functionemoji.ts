function emojify(message:any,emoji:string):string{

return String(message);

}

console.log(emojify(1,"hello"));