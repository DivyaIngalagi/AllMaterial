//window.alert("set statusbar.");

//window.prompt("enter your name:");

//window.defaultStatus = "hello javascript";

let globalPrice = 12;

// function globalFunction() {
//   var globalPrice = 12;
// }
