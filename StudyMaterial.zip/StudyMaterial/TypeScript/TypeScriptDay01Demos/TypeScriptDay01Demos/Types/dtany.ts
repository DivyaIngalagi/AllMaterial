let something:any = "Hello";
console.log(something);
something = 123;
console.log(123);
something = true;
console.log(true);

let input:any[];
input = [1,'Sachin Tendulkar',46]
input.push(2,'Pusarla Sindhu',36);
console.log(input); 
