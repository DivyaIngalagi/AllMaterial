var employeeName = "John Smith";
var employeeDept = "Finance";
// Pre-ES6 
var employeeDesc1 = employeeName + " works in the " + employeeDept + " department.";
// Post-ES6 
var employeeDesc2 = "".concat(employeeName, " works in ").concat(employeeDept);
console.log(employeeDesc1); //John Smith works in the Finance department. 
console.log(employeeDesc2); //John Smith works in the Finance department.
console.log(employeeName.charAt(0));
console.log(employeeName.charAt(2));
console.log(employeeName.concat(employeeDept));
console.log(employeeName.indexOf('S'));
console.log(employeeName.indexOf('S', 3));
console.log(employeeName.replace("Smith", "Hopkins"));
console.log(employeeName.indexOf('S'));
console.log(employeeName.indexOf('S', 3));
console.log(employeeName.replace("Smith", "Hopkins"));
console.log(employeeName.toUpperCase());
console.log(employeeName.toLowerCase());
console.log(employeeName);
