// enum PrintMedia {
//     Newspaper = 1,
//     Newsletter = 5,
//     Magazine = 9,
//     Book = 10
// } 
// console.log(PrintMedia);
// console.log(PrintMedia.Magazine);
// console.log(PrintMedia.Newsletter); 
var PrintMedia;
(function (PrintMedia) {
    PrintMedia["Newspaper"] = "NEWSPAPER";
    PrintMedia["Newsletter"] = "NEWSLETTER";
    PrintMedia["Magazine"] = "MAGAZINE";
    PrintMedia["Book"] = "BOOK";
})(PrintMedia || (PrintMedia = {}));
// // Access String Enum 
console.log(PrintMedia.Newspaper); //returns NEWSPAPER
console.log(PrintMedia['Magazine']); //returns MAGAZINE
function getMedia(mediaName) {
    if (mediaName === 'Forbes' || mediaName === 'Outlook') {
        return PrintMedia.Magazine;
    }
}
var mediaType = getMedia('Forbes');
console.log(mediaType);
