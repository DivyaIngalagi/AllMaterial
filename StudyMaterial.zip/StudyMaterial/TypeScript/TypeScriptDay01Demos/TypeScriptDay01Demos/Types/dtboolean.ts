let isPresent:boolean = true;
console.log(isPresent);