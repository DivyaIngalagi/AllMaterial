var isPresent = true;
console.log(isPresent);
