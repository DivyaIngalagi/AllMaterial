var employee = [100, "Karthikeyan"];
employee.push("divya");
employee.push(20, "Hello");
console.log(employee);
console.log(employee[1]);
// console.log(typeof(employee[1]));
employee[1] = employee[1].concat("Jobs");
console.log(employee[0]);
// console.log(employee[3]+" "+employee[4]);
/*var employee = [100,"Karthikeyan"];
employee.push("Ajit");
employee.push(10);
console.log(employee);
//employee[1] = employee[1].concat("Jobs");
console.log(employee[0]);
console.log(employee[3]);*/
var employees;
employees = [
    [1, "Nachiket"],
    [2, "Bhushan"],
    [3, "Vaishali"],
];
console.log(employees[0]);
console.log(employees[1]);
var a = [];
a.push(10);
