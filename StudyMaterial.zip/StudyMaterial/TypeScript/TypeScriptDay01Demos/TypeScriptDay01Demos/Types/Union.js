var code;
code = 123;
console.log(code);
code = "ABC";
console.log(code);
var employeeId;
employeeId = 11013;
console.log(employeeId);
employeeId = "CT11013";
console.log(employeeId);
function displayType(code) {
    if (typeof (code) === "number")
        console.log('code is numeric');
    else if (typeof (code) === "string")
        console.log('code is alphanumeric');
}
displayType(123);
displayType("CT123");
