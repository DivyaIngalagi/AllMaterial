let fruits:Array<string>;
fruits=['Apple','Banana','Mango'];
for(var index in fruits)
{
    console.log(fruits[index]);
}

let ids:number[]=[1,2,3,4,5];
for(var i = 0; i<ids.length;i++)
{
    console.log(ids[i]);
}