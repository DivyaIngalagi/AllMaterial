var a = "34sample text";
var b = 123;
a = b; //error as a is of type string and b is of type number
console.log(a + 1);
b = a;
console.log(b + 1);
var arr = [10, null, 30, 40];
console.log(typeof (arr));
arr.push(10);
console.log(arr);
console.log(arr[4]);
var arr2 = [1, 2, "Hello"];
console.log(typeof (arr2));
arr2.push(null);
arr2.push("World");
//arr2.push(true); //error as true is not of type number or string
console.log(arr2);
function sum(a, b) {
    return a + b;
}
var total = sum(10, 20); // OK
console.log(total);
//var str: string = sum(10,20); // Compiler Error 
