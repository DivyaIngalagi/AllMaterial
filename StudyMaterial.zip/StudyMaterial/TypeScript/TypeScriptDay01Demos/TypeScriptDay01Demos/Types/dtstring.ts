let employeeName:string = "John Smith"; 
let employeeDept:string = "Finance"; 

// Pre-ES6 
let employeeDesc1: string = employeeName + " works in the " + employeeDept + " department."; 

// Post-ES6 
let employeeDesc2: string = `${employeeName} works in ${employeeDept}`;

console.log(employeeDesc1);//John Smith works in the Finance department. 
console.log(employeeDesc2);//John Smith works in the Finance department.
console.log(employeeName.charAt(0)); 
console.log(employeeName.charAt(2));
console.log(employeeName.concat(employeeDept));
console.log(employeeName.indexOf('S'));
console.log(employeeName.indexOf('S',3));
console.log(employeeName.replace("Smith","Hopkins"));
console.log(employeeName.indexOf('S'));
console.log(employeeName.indexOf('S',3));
console.log(employeeName.replace("Smith","Hopkins"));
console.log(employeeName.toUpperCase());
console.log(employeeName.toLowerCase());
console.log(employeeName);