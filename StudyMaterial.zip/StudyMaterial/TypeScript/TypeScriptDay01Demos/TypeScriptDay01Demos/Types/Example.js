var x = "123ac";
var y = parseInt(x);
console.log(y);
var a;
a = "123abc";
a = parseInt(a) + 4;
//(a as string);
//(<string>a);
console.log(a);
