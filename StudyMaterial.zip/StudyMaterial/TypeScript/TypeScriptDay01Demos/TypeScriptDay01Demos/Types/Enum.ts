// enum PrintMedia {
//     Newspaper = 1,
//     Newsletter = 5,
//     Magazine = 9,
//     Book = 10
// }
// console.log(PrintMedia);
// console.log(PrintMedia.Magazine);
// console.log(PrintMedia.Newsletter);

enum PrintMedia {
  Newspaper = "NEWSPAPER",
  Newsletter = "NEWSLETTER",
  Magazine = "MAGAZINE",
  Book = "BOOK",
}
// // Access String Enum
console.log(PrintMedia.Newspaper); //returns NEWSPAPER
console.log(PrintMedia["Magazine"]); //returns MAGAZINE

function getMedia(mediaName: string): PrintMedia {
  if (mediaName === "Forbes" || mediaName === "Outlook") {
    return PrintMedia.Magazine;
  }
}

let mediaType: PrintMedia = getMedia("Forbes");
console.log(mediaType);
