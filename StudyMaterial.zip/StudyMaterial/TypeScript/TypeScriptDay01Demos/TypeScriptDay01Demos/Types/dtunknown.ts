let value:any;
value = true;
console.log(value);
let result:boolean = value;
console.log(result);

/*let sample:unknown;
sample = false;
console.log(sample);
let testvar:boolean = sample;*/

let sample:unknown;
sample=true;
console.log(sample);
//gives error
// let endresult:boolean=sample;
// console.log(endresult);
let activeEmployee = sample as boolean;
console.log('Is employee is still working with us?'+activeEmployee);

function demoFunction(param:unknown){
    if(typeof param === "string")
        console.log(param.toUpperCase());
    if(typeof param === "number")
        console.log((param/10)*100);
    if(param instanceof Date)
        console.log(param);
}

demoFunction("Hello All!!");
demoFunction(72);
demoFunction(new Date());