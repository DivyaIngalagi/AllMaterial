var employeeid = 1001;
var firstName = "Sachin";
var lastName = "Tendulkar";
var dob = new Date(1976, 3, 24);
var activePlayer = false;
var allowance = 5000.79;
//allowance="string";//not reassignable
var iplAssociation = "Not yet decided";
var remuneration = 10000000; //Type Inference: Data type is inferred by TypeScript based on value assigned to the variable
//remuneration="String";//not assignable;
console.log("Employee Id:" + employeeid);
console.log("First Name:" + firstName);
console.log("Last Name:" + lastName);
console.log("Born On:" + dob);
console.log("Allowance:" + allowance);
console.log("League:" + iplAssociation);
console.log("iplAssociation is of type:" + typeof (iplAssociation));
iplAssociation = false;
console.log("IPL Player?:" + iplAssociation);
var something = "Hello All!!!";
//let message:string = something;   //error as unknown is assignable only to unknown and any
if (typeof something === "string")
    console.log(something.toUpperCase());
something = 125;
if (typeof something === "number")
    console.log(something / 10);
something = new Date();
if (something instanceof Date)
    console.log(something);
