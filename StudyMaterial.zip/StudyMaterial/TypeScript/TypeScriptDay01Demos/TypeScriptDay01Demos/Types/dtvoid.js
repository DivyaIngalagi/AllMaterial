function sayHi() {
    console.log("Hi");
    return "HI";
}
;
var speech = sayHi();
console.log(speech);
