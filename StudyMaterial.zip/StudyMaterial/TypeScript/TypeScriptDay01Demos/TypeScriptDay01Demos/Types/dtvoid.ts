function sayHi():void{
    console.log("Hi")
};
let speech:void = sayHi();
console.log(speech);