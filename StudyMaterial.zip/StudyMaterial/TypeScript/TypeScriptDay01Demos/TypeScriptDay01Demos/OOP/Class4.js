var Circle = /** @class */ (function () {
    function Circle() {
        this.pi = 3;
    }
    Circle.calculateArea = function (radius) {
        return this.pi * radius * radius;
    };
    Circle.prototype.calculateCircumference = function (radius) {
        return 2 * Circle.pi * radius;
    };
    Circle.pi = 3.14;
    return Circle;
}());
var area = Circle.calculateArea(5); // returns 78.5
console.log(area);
var circleObj = new Circle();
var circumference = circleObj.calculateCircumference(5); // returns 31.4000000
console.log(circumference);
console.log(circleObj.pi);
//circleObj.calculateArea(); //cannot call this
