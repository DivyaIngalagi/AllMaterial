class Circle {
    static pi = 3.14;
    pi = 3;
    static calculateArea(radius:number) {
        return this.pi * radius * radius;
    }

    calculateCircumference(radius:number):number { 
        return 2 * Circle.pi * radius;
    }
}

let area:number = Circle.calculateArea(5); // returns 78.5
console.log(area);

let circleObj = new Circle();
let circumference:number = circleObj.calculateCircumference(5); // returns 31.4000000
console.log(circumference);
console.log(circleObj.pi);
//circleObj.calculateArea(); //cannot call this