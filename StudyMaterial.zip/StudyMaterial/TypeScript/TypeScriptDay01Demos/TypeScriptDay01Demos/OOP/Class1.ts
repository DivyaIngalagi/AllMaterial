class Employee {
    empCode:number;
    empName:string;

    constructor(code:number,name:string) {
        this.empCode = code;
        this.empName = name;
    }

    getSalary():number {
        return 10000;
    }
}

let emp1 = new Employee(1001,"Sachin");
console.log('Employee1 Id'+emp1.empCode);
console.log('Employee1 Name'+emp1.empName);
let salary:number = emp1.getSalary();
console.log('Employee1 Salary'+salary);
