function add(a, b) {
    return a + b;
}
var greeting = add("Hello ", "Steve"); // returns "Hello Steve" 
console.log(greeting);
var addition = add(10, 20); // returns 30 
console.log(addition);
