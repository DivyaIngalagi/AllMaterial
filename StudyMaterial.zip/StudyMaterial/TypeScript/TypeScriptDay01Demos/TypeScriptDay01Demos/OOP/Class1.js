var Employee = /** @class */ (function () {
    function Employee(code, name) {
        this.empCode = code;
        this.empName = name;
    }
    Employee.prototype.getSalary = function () {
        return 10000;
    };
    return Employee;
}());
var emp1 = new Employee(1001, "Sachin");
console.log('Employee1 Id' + emp1.empCode);
console.log('Employee1 Name' + emp1.empName);
var salary = emp1.getSalary();
console.log('Employee1 Salary' + salary);
