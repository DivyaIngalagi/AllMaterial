var Employee = /** @class */ (function () {
    function Employee(name) {
        this.empName = name;
    }
    Object.defineProperty(Employee.prototype, "empCode", {
        get: function () {
            return this._empCode;
        },
        set: function (code) {
            if (code <= 0 || code > 1000) {
                throw new Error("Invalid Employee Code");
            }
            this._empCode = code;
        },
        enumerable: false,
        configurable: true
    });
    Employee.prototype.getSalary = function () {
        return 10000;
    };
    return Employee;
}());
/*let emp1 = new Employee(1001,"Sachin");*/
var emp1 = new Employee("Sindhu");
emp1.empCode = 107;
var salary = emp1.getSalary();
console.log('Employee1 Id' + emp1.empCode);
console.log('Employee1 Name' + emp1.empName);
console.log('Employee1 Salary' + emp1.getSalary());
