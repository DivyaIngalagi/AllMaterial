class Employee {
    private _empCode:number;
    public empName:string;

    constructor(name:string) {
        this.empName = name;
    }

    public get empCode() {
        return this._empCode;
    }

    public set empCode(code:number) {
        if(code <= 0 || code > 1000) {
            throw new Error("Invalid Employee Code");
        }
        this._empCode = code;
    }

    getSalary():number {
        return 10000;
    }
}

/*let emp1 = new Employee(1001,"Sachin");*/
let emp1 = new Employee("Sindhu");
emp1.empCode = 107;
let salary:number = emp1.getSalary();
console.log('Employee1 Id'+emp1.empCode);
console.log('Employee1 Name'+emp1.empName);
console.log('Employee1 Salary'+emp1.getSalary());