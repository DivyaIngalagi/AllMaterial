function add(a, b, c) {
    if (b === undefined && c === undefined) {
        return a;
    }
    else if (c === undefined) { //if we add anything with undefinr answer is NAN
        return a + b;
    }
    else {
        return a + b + c;
    }
}
// let greeting:string = add("Hello ","a","b"); // returns "Hello Steve" 
// console.log(greeting);
// let greeting1:string = add("Hello "); // returns "Hello Steve" 
// console.log(greeting1);
var addition1 = add(10); // returns 30 
console.log(addition1);
var addition2 = add(10, 20); // returns 30 
console.log(addition2);
var addition3 = add(10, 20, 30); // returns 30 
console.log(addition3);
var addition4 = add(10, 20, 30, 40); // returns 30 
console.log(addition4);
