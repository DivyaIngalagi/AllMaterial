class Person {
    name: string;
}

interface IEmployee extends Person { 
    empCode: number;
}
/*class IEmployee extends Person {
    empCode: number; 
    constructor(a:number,b:string){
        super();
        this.empCode=a;
        this.name=b;
    }*/
let emp: IEmployee = { empCode  : 1, name:"James Bond" }
console.log(emp.empCode);
console.log(emp.name);