var Person = /** @class */ (function () {
    function Person() {
    }
    return Person;
}());
/*class IEmployee extends Person {
    empCode: number;
    constructor(a:number,b:string){
        super();
        this.empCode=a;
        this.name=b;
    }*/
var emp = { empCode: 1, name: "James Bond" };
console.log(emp.empCode);
console.log(emp.name);
