//function add(a:string,b:string,c:string):string;
function add(a:number): number;
function add(a:number, b:number): number;
function add(a:number, b:number,c:number): number;
function add(a:number, b:number,c:number,d:number): number;
function add(a: any, b?:any,c?:any): any {
    if(b===undefined&&c===undefined){
        return a;
    }
    else if(c===undefined){//if we add anything with undefinr answer is NAN
     return a+b;
    }
    else{
        return a+b+c;
    }
}

// let greeting:string = add("Hello ","a","b"); // returns "Hello Steve" 
// console.log(greeting);
// let greeting1:string = add("Hello "); // returns "Hello Steve" 
// console.log(greeting1);
let addition1:number = add(10); // returns 30 
console.log(addition1);
let addition2:number = add(10, 20); // returns 30 
console.log(addition2);
let addition3:number = add(10, 20,30); // returns 30 
console.log(addition3);
let addition4:number = add(10, 20,30,40); // returns 30 
console.log(addition4);


/*

function add(a:number,b:string):string;
function add(s1:string,s2:string):string;

function add(a:any,b:any):any{
if((typeof(a)==="number"||typeof(a)==="string"))
    return a+b;

}

let number_summation:string=add(10,"divya");
console.log(number_summation);
let string_summation:string=add("divya","anand");
console.log(string_summation);*/