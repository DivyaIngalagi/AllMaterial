let World = "world";
// let Greeting = `hello ${World}`;
let Greeting = "hello"+World;
console.log(Greeting);