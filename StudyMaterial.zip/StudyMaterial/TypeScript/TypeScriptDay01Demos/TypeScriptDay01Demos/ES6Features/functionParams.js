function applyDiscount(price, discount) {
    if (discount === void 0) { discount = 5; }
    price = price - (price * discount / 100);
    return price;
}
var discountedPrice = applyDiscount(200);
console.log('Price after discount: ' + discountedPrice);
discountedPrice = applyDiscount(370, 10);
console.log('Price after passing discount: ' + discountedPrice);
function multiply() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    var answer = 1;
    for (var arg = 0; arg < args.length; arg++) {
        answer *= args[arg];
    }
    return answer;
}
var multiplication = multiply(10, 5, 7);
console.log('Multiplication using Rest & Spread Operator ' + multiplication);
multiplication = multiply(10, 5, 7, 2);
console.log('Multiplication using Rest & Spread Operator ' + multiplication);
function Test(a) {
    var restParam = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        restParam[_i - 1] = arguments[_i];
    }
    console.log(a); // 1
    console.log(restParam[0]); // [1,2]
    console.log(restParam);
}
Test(1, 2, 3);
Test(1, "Hello", "All", "TS REST and SPREAD");
Test(1, 2, 3, 4, 5);
// function Test1(...restParam:number[]){
// function Test1(a,...restParam){
function Test1(a) {
    var restParam = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        restParam[_i - 1] = arguments[_i];
    }
    console.log(a); // 1
    console.log(restParam[0]); // [2]
    console.log(restParam.join(","));
    console.log(a + " " + restParam.join(", ") + "!");
}
Test1(1, 2, 3);
// Test1(1,"Hello","All","TS REST and SPREAD");
Test1(1, 2, 3, 4, 5);
