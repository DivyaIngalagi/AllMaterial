const num:number = 100;
console.log(num);
/*error as num is const*/
//  num =200; 

const playerCodes = {
    player1 : 7,
    player2 : 9,
    player3 : 6,
    player4 : 10
}
playerCodes.player2 = 14;  //allowed
console.log(playerCodes.player1);
console.log(playerCodes.player2);

/*
playerCodes = {     //Compiler Error: Cannot assign to playerCodes because it is a constant or read-only
    player1 : 50,   // Modified value
    player2 : 10, 
    player3 : 13, 
    player4 : 20
};*/ 