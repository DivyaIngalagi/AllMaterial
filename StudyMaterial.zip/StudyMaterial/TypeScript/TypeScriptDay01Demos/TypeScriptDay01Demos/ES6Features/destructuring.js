/*
Destructuring
Destructuring assignment is a syntax that allows you to assign object properties or array items as variables.
This can greatly reduce the lines of code necessary to manipulate data in these structures.
There are two types of destructuring: Object destructuring and Array destructuring.
*/
/*
Object Destructuring
Object destructuring allows you to create new variables using an object property as the value.
*/
var note = {
    id: 1,
    title: 'My first note',
    date: '01/01/1970'
};
// const note2=note;
// console.log(note2.id);
// const note3={ id:note.id, title:note.title};
// console.log("mote3",note3.id);
// console.log("mote3",note3.title);
var title = note.title, id = note.id;
console.log(id);
console.log(title);
// console.log(date);
/*
Array Destructuring
Array destructuring allows you to create new variables using an array item as a value.
*/
var doj = ['2021', '10', '11'];
var year = doj[0], month = doj[1], day = doj[2];
console.log(year);
console.log(month);
console.log(day);
var yoj = doj[0], dateOfJoining = doj[2];
console.log(yoj);
console.log(dateOfJoining);
