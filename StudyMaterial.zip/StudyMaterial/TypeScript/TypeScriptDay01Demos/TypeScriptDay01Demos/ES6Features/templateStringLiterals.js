var World = "world";
// let Greeting = `hello ${World}`;
var Greeting = "hello" + World;
console.log(Greeting);
