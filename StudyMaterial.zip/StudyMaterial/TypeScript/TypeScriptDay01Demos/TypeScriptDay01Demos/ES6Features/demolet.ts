let num1:number = 1; 
num1=3;
function letDeclaration() { 
    let num2:number = 2; 

    if (num2 > num1) { 
        let num3: number = 3;
        num3++; 
        //num2=7;
        console.log(num3);
        num3=8;
        console.log(num3);
    }
    while(num1 < num2) { 
        let num4: number = 4;
        num1++;
    }
    //num1=3
    console.log(num1); //2
    console.log(num2); //2 
    //console.log(num3); //Compile Time Error
    //console.log(num4); //Compile Time Error
}
/* not allowed with let
num5 = 1000;
let num5; */

function letDemo(a: number ) { 
    //let a:number = 10 ; //Compiler Error: TS2300: Duplicate identifier 'a'
    let b:number = 20 ; 

    return a + b ;
}


letDeclaration();