function applyDiscount(price:number, discount:number = 5) {
    price = price - (price*discount/100);
    return price;
}

let discountedPrice:number = applyDiscount(200);
console.log('Price after discount: '+discountedPrice);
discountedPrice = applyDiscount(370,10);
console.log('Price after passing discount: '+discountedPrice);



function multiply(...args: number[]){
    let answer:number = 1;
    for(let arg:number = 0;arg<args.length;arg++) {
        answer *= args[arg];
    }
    return answer;
}

let multiplication = multiply(10,5,7);
console.log('Multiplication using Rest & Spread Operator '+multiplication);
multiplication = multiply(10,5,7,2);
console.log('Multiplication using Rest & Spread Operator '+multiplication);

function Test(a,...restParam){
    console.log(a); // 1
    console.log(restParam[0]) // [1,2]
    console.log(restParam)
}
Test(1,2,3);
Test(1,"Hello","All","TS REST and SPREAD");
Test(1,2,3,4,5);

// function Test1(...restParam:number[]){
// function Test1(a,...restParam){
    function Test1(a,...restParam){
    console.log(a); // 1
    console.log(restParam[0]) // [2]
    console.log(restParam.join(","))
    console.log(a + " " + restParam.join(", ") + "!")
}
Test1(1,2,3);
// Test1(1,"Hello","All","TS REST and SPREAD");
Test1(1,2,3,4,5);


