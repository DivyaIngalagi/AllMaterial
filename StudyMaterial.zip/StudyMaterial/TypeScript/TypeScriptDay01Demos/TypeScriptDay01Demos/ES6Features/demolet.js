var num1 = 1;
num1 = 3;
function letDeclaration() {
    var num2 = 2;
    if (num2 > num1) {
        var num3 = 3;
        num3++;
        //num2=7;
        console.log(num3);
        num3 = 8;
        console.log(num3);
    }
    while (num1 < num2) {
        var num4 = 4;
        num1++;
    }
    //num1=3
    console.log(num1); //2
    console.log(num2); //2 
    //console.log(num3); //Compile Time Error
    //console.log(num4); //Compile Time Error
}
/* not allowed with let
num5 = 1000;
let num5; */
function letDemo(a) {
    //let a:number = 10 ; //Compiler Error: TS2300: Duplicate identifier 'a'
    var b = 20;
    return a + b;
}
letDeclaration();
