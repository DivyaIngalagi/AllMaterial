/*let data;
data="string";
// data=10;
let item:string="ananad";
let item2:number=19;
item2=data;
//item2=item;//error
//if(typeof(data)=="string"){
 //   item=data;
   // item=item+10;
//}
console.log(item2+1);
console.log(typeof(data));
console.log(typeof(item));*/
var data; //it is not sure
data = "string";
// data=10;
var item = "1323anand";
var item2 = 19;
item2 = parseInt(item);
console.log(item2);
console.log(typeof (item2));
item2 = data; //error not sure
////if(typeof(data)=="string"){
//  item=data;
//}
//item2=item;//error
console.log(item);
console.log(typeof (data));
console.log(typeof (item2));
