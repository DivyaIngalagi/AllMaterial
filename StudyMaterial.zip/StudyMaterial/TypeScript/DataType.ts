let empid:number=101;
console.log(empid);