var empid = 101;
console.log(empid);
