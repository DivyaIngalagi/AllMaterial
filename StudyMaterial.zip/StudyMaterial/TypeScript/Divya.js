var empasdasd = 101;
// let frstname: string = "Divya";
// let active: boolean = true;
// let dob: Date = new Date(2020, 4, 12);
var local = "hello hii";
var n = local;
console.log(empasdasd);
console.log(local);
console.log(n);
