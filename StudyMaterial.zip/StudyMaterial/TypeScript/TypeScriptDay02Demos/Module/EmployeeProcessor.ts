// import *  as Emp from "./Employee";//* as Emp without bracket if we need all
import { Employee } from "./Employee";
/*let empObj = new Emp.Employee("Steve Jobs", 1);
console.log(Emp.age);
empObj.displayEmployee(); //Output: Employee Code: 1, Employee Name: Steve Jobs  
*/

let empObj = new Employee("Steve Jobs", 1);
// console.log(empObj.age);//error
empObj.displayEmployee(); //Output: Employee Code: 1, Employee Name: Steve Jobs  