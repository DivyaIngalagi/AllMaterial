var employee:[number,string] = [1,"Karthikeyan"];
employee.push(2,"Ajit");
console.log(employee);
employee[1] = employee[1].concat("Jobs");
console.log(employee);
for(let index:number=0;index<employee.length;index++){
    console.log(employee[index]);
}


var employees:[number,string][];
employees = [[1,"Nachiket"],[2,"Bhushan"],[3,"Vaishali"]];
console.log(employees);

console.log("Accessing second record");
console.log(employees[1]);