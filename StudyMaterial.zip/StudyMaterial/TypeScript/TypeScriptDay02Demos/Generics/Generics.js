function getArray(items) {
    return new Array();
}
var myNumArr = getArray([100, 200, 300]);
var myStrArr = getArray(["Hello", "World"]);
myNumArr.push(400); // OK
myNumArr.push(500);
myNumArr.concat(600);
console.log(myNumArr);
myStrArr.push("Hello TypeScript"); // OK
myStrArr.push("TypeScript Generics are Cool");
console.log(myStrArr);
//myNumArr.push("Hi"); // Compiler Error
//myStrArr.push(500); // Compiler Error
