/*function merge<U , V >(obj1: U, ..._obj2: V[]):U,V[] {

        return obj1,obj2
    
}
let person = merge(
    1,2,3,4,5);

console.log(person);*/


/*
let person2 = merge(
    { name: 'John' },
    25
);

console.log(person2);
*/ //Gives error


function merge<U , V >(U,V) {
    if(typeof(U)==="number"&&typeof(V)==="number"){
        console.log("n");
    return U+V;
    }
    if(typeof(U)==="string"&&typeof(V)==="string"){
        console.log("s");
        return U+V;
        }else{
            console.log("b");
        return -1;
        }
}

let m=merge(1,5);
let m1=merge("divya","anand");
let m3=merge(true,false);
console.log(m);
console.log(m1);
console.log(m3);

