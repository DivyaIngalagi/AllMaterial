const Add = (firstNumber:number,secondNumner:number):number => firstNumber + secondNumner;
const addition = Add(150,290);
console.log('Addition of two numbers is '+addition);

const Subtract = (firstNumber:number,secondNumner:number):number => firstNumber - secondNumner;
const sub = Subtract(150,290);
console.log('Subtraction of two numbers is '+sub);

const Multiply = (firstNumber:number,secondNumner:number):number => firstNumber * secondNumner;
const mul = Multiply(150,290);
console.log('Multiplication of two numbers is '+mul);

const Divide = (firstNumber:number,secondNumner:number):number => firstNumber / secondNumner;
const div = Divide(150,290);
console.log('Addition of two numbers is '+div);