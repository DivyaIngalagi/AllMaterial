class Account{

    account_id:number;
    account_name:string;
    initial_balance:number;
    private static account_count:number=0;//otherwise NAN it will show

    constructor(acc_id:number=0,name:string='',initial_bal:number=0){
        this.account_id=acc_id;
        this.account_name=name;
        this.initial_balance=initial_bal;
        Account.account_count++;
    }

    Withdraw(amount:number) {
        if(this.initial_balance==0){
            this.Log("Withdraw Operation");
            return "Not have Sufficient balance!!!!Available balance is:"+this.initial_balance;
        }
        else{
        this.Log("Withdraw Operation");
        return this.initial_balance=this.initial_balance-amount;
        }
    }

    Deposit(amount:number) {
        this.Log("Deposit Operation");
        return this.initial_balance=this.initial_balance+amount;
    }
    
    private Log(anything:string){
        console.log(anything);
    }

    static CountAccounts():number {
        return this.account_count;
    }

}

let Accountobj:Account[]=[];
Accountobj[0]=new Account();
Accountobj[1]=new Account(1,"divya",1000);
Accountobj[2]=new Account(2,"anand",5000);
console.log("The total Account is:"+Account.CountAccounts());

for(let i=0;i<Accountobj.length;i++){
    console.log("--------------------------");
    console.log(Accountobj[i].Withdraw(100));
    console.log(Accountobj[i].Deposit(100));
    console.log(Accountobj[i].initial_balance);
    console.log("--------------------------");
}


