export default interface IFlyMod{

    fly():string;

}