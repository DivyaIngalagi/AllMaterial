"use strict";
exports.__esModule = true;
exports.MissileMo = exports.SupermanMo = exports.SparrowMo = void 0;
var SparrowMo = /** @class */ (function () {
    function SparrowMo() {
    }
    SparrowMo.prototype.fly = function () {
        return "Sparrow can Fly.";
    };
    return SparrowMo;
}());
exports.SparrowMo = SparrowMo;
var SupermanMo = /** @class */ (function () {
    function SupermanMo() {
    }
    SupermanMo.prototype.fly = function () {
        return "Superman can Fly.";
    };
    return SupermanMo;
}());
exports.SupermanMo = SupermanMo;
var MissileMo = /** @class */ (function () {
    function MissileMo() {
    }
    MissileMo.prototype.fly = function () {
        return "Missile can Fly.";
    };
    return MissileMo;
}());
exports.MissileMo = MissileMo;
