abstract class Sorter{

    abstract sort():string;

}

class Linear implements Sorter{
    sort(): string {
       return "Linear sort implemented.";
    }
}

class Bubble implements Sorter{
    sort(): string {
        return "Bubble sort implemented.";
    }
}

let sort:Sorter[]=[];
sort[0]=new Linear();
sort[1]=new Bubble();

for(let i=0;i<sort.length;i++){
    console.log(sort[i].sort());
}