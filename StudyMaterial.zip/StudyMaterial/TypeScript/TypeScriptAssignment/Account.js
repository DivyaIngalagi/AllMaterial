var Account = /** @class */ (function () {
    function Account(acc_id, name, initial_bal) {
        if (acc_id === void 0) { acc_id = 0; }
        if (name === void 0) { name = ''; }
        if (initial_bal === void 0) { initial_bal = 0; }
        this.account_id = acc_id;
        this.account_name = name;
        this.initial_balance = initial_bal;
        Account.account_count++;
    }
    Account.prototype.Withdraw = function (amount) {
        if (this.initial_balance == 0) {
            this.Log("Withdraw Operation");
            return "Not have Sufficient balance!!!!Available balance is:" + this.initial_balance;
        }
        else {
            this.Log("Withdraw Operation");
            return this.initial_balance = this.initial_balance - amount;
        }
    };
    Account.prototype.Deposit = function (amount) {
        this.Log("Deposit Operation");
        return this.initial_balance = this.initial_balance + amount;
    };
    Account.prototype.Log = function (anything) {
        console.log(anything);
    };
    Account.CountAccounts = function () {
        return this.account_count;
    };
    Account.account_count = 0; //otherwise NAN it will show
    return Account;
}());
var Accountobj = [];
Accountobj[0] = new Account();
Accountobj[1] = new Account(1, "divya", 1000);
Accountobj[2] = new Account(2, "anand", 5000);
console.log("The total Account is:" + Account.CountAccounts());
for (var i = 0; i < Accountobj.length; i++) {
    console.log("--------------------------");
    console.log(Accountobj[i].Withdraw(100));
    console.log(Accountobj[i].Deposit(100));
    console.log(Accountobj[i].initial_balance);
    console.log("--------------------------");
}
