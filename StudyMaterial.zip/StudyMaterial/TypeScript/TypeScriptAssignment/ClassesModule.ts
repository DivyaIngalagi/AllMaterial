import IFlyMod  from "./InterfaceModule";
export class SparrowMo implements IFlyMod{

    fly(): string {
        return "Sparrow can Fly.";
    }
}

export class SupermanMo implements IFlyMod{
    fly(): string {
        return "Superman can Fly.";
    }
}

export class MissileMo implements IFlyMod{
    fly(): string {
        return "Missile can Fly.";
    }
}