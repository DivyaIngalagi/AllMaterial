function merge<U , V >(n1:string|number,n2:string|number) {
    if(typeof(n1)==="number"&&typeof(n2)==="number"){
        console.log("n");
    return n1+n2;
    }
    else if(typeof(n1)==="string"&&typeof(n2)==="string"){
        console.log("s");
        return n1+n2;
        }else if(typeof(n1)==="string"&&typeof(n2)==="number"){
            return n1+n2;
            }
}

let m=merge(1,5);
let m1=merge("divya","anand");
let m2=merge("divya",20);
// let m3=merge(true,false);
console.log(m);
console.log(m1);
console.log(m2);
// console.log(m3);

//function merge<U , V >(n1:string|number,n2:string|number) {