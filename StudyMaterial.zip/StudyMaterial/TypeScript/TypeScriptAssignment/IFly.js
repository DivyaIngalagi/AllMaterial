var Sparrow = /** @class */ (function () {
    function Sparrow() {
    }
    Sparrow.prototype.fly = function () {
        return "Sparrow can Fly.";
    };
    return Sparrow;
}());
var Superman = /** @class */ (function () {
    function Superman() {
    }
    Superman.prototype.fly = function () {
        return "Superman can Fly.";
    };
    return Superman;
}());
var Missile = /** @class */ (function () {
    function Missile() {
    }
    Missile.prototype.fly = function () {
        return "Missile can Fly.";
    };
    return Missile;
}());
var bird = [];
bird[0] = new Sparrow();
bird[1] = new Superman();
bird[2] = new Missile();
for (var i = 0; i < bird.length; i++) {
    console.log(bird[i].fly());
}
