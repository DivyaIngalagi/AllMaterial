var Sorter = /** @class */ (function () {
    function Sorter() {
    }
    return Sorter;
}());
var Linear = /** @class */ (function () {
    function Linear() {
    }
    Linear.prototype.sort = function () {
        return "Linear sort implemented.";
    };
    return Linear;
}());
var Bubble = /** @class */ (function () {
    function Bubble() {
    }
    Bubble.prototype.sort = function () {
        return "Bubble sort implemented.";
    };
    return Bubble;
}());
var sort = [];
sort[0] = new Linear();
sort[1] = new Bubble();
for (var i = 0; i < sort.length; i++) {
    console.log(sort[i].sort());
}
