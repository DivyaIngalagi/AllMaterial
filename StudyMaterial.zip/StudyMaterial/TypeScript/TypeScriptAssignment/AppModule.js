"use strict";
exports.__esModule = true;
var birds = require("./ClassesModule");
var bird = [];
bird[0] = new birds.SparrowMo();
bird[1] = new birds.SupermanMo();
bird[2] = new birds.MissileMo();
for (var i = 0; i < bird.length; i++) {
    console.log(bird[i].fly());
}
