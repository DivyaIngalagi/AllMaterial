interface IFly{

    fly():string;

}


class Sparrow implements IFly{

    fly(): string {
        return "Sparrow can Fly.";
    }
}

class Superman implements IFly{
    fly(): string {
        return "Superman can Fly.";
    }
}

class Missile implements IFly{
    fly(): string {
        return "Missile can Fly.";
    }
}

let bird:IFly[]=[];
bird[0]=new Sparrow();
bird[1]=new Superman();
bird[2]=new Missile();

for(let i=0;i<bird.length;i++){
    console.log(bird[i].fly());
}